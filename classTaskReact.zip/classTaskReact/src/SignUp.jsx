


function SignUp() {
    return(
    <div>
    <form className="SignUp">
        
        <input type="text" id="email"  placeholder="Email"/>
        <input type="text" id="Firstname"  placeholder="Firstname"/>
        <input type="text" id="Lastname"  placeholder="Lasttname"/>
        <input type="text" id="password"  placeholder="Password"/>
        <button type="button"> </button>

    </form>
</div>
    
)}

export default SignUp