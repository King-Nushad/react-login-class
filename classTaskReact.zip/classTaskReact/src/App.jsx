import React from 'react'
import './App.css'
import SignUp from './SignUp'
import Login from './Login'


function App() {

  return (
    <>
   
    <div>
      <h1>WELCOME</h1>

 
    <Login />

    <SignUp />
    </div>
    </>
  )
}

export default App
