

function Login() {
    return (
        <div>
            <form className="login">
                
                <input type="text" id="email"  placeholder="Email"/> <br />
                <input type="text" id="password"  placeholder="Password"/> <br />
                <button type="button">Login</button>

            </form>
        </div>
    )
}

export default Login;